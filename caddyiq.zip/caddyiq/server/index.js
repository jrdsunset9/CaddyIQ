require("dotenv").config();
const express    = require("express");
const multer     = require("multer");
const cors       = require("cors");
const path       = require("path");
const fs         = require("fs");
const os         = require("os");
const { v4: uuidv4 } = require("uuid");
const ffmpeg     = require("fluent-ffmpeg");
const ffmpegPath = require("@ffmpeg-installer/ffmpeg").path;
const axios      = require("axios");

ffmpeg.setFfmpegPath(ffmpegPath);

const app  = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json());

// ── Serve React build in production ──────────────────────────
const clientBuild = path.join(__dirname, "../client/dist");
if (fs.existsSync(clientBuild)) {
  app.use(express.static(clientBuild));
}

// ── Multer: accept video + image uploads up to 500MB ─────────
const upload = multer({
  dest: os.tmpdir(),
  limits: { fileSize: 500 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = /video\/(mp4|quicktime|x-m4v|avi|x-matroska|webm|3gpp)|image\/(jpeg|png|heic|heif|webp)/i;
    if (allowed.test(file.mimetype) || file.originalname.match(/\.(mp4|mov|m4v|avi|mkv|webm|3gp|jpg|jpeg|png|heic|heif)$/i)) {
      cb(null, true);
    } else {
      cb(new Error("Unsupported file type"), false);
    }
  },
});

// ── Helper: extract N frames from video using FFmpeg ─────────
function extractFrames(videoPath, numFrames = 6) {
  return new Promise((resolve, reject) => {
    const frameDir  = path.join(os.tmpdir(), uuidv4());
    fs.mkdirSync(frameDir, { recursive: true });

    // First get video duration
    ffmpeg.ffprobe(videoPath, (err, metadata) => {
      if (err) { reject(new Error("Could not read video metadata: " + err.message)); return; }

      const duration = metadata.format.duration || 3;
      const interval = duration / (numFrames + 1);

      // Build select filter to grab frames at evenly spaced timestamps
      // We target: setup, early takeaway, top of backswing, downswing, impact, follow-through
      const timestamps = Array.from({ length: numFrames }, (_, i) =>
        Math.min(interval * (i + 1), duration - 0.1).toFixed(2)
      );
      const selectFilter = timestamps.map(t => `eq(t\\,${t})`).join("+");

      ffmpeg(videoPath)
        .outputOptions([
          `-vf`, `select='${selectFilter}',scale=1024:-2`,
          `-vsync`, `vfr`,
          `-q:v`, `3`,
          `-frames:v`, `${numFrames}`,
        ])
        .output(path.join(frameDir, "frame_%03d.jpg"))
        .on("end", () => {
          const files = fs.readdirSync(frameDir)
            .filter(f => f.endsWith(".jpg"))
            .sort()
            .map(f => path.join(frameDir, f));
          resolve({ files, frameDir, timestamps, duration });
        })
        .on("error", (e) => reject(new Error("FFmpeg frame extraction failed: " + e.message)))
        .run();
    });
  });
}

// ── Helper: file → base64 ─────────────────────────────────────
function fileToBase64(filePath) {
  const buf = fs.readFileSync(filePath);
  return buf.toString("base64");
}

// ── Helper: cleanup temp files ────────────────────────────────
function cleanup(...paths) {
  paths.forEach(p => {
    try {
      if (fs.statSync(p).isDirectory()) fs.rmSync(p, { recursive: true, force: true });
      else fs.unlinkSync(p);
    } catch {}
  });
}

// ── POSITION LABELS for each frame ───────────────────────────
const POSITION_LABELS = [
  "Address / Setup (P1)",
  "Early takeaway (P2)",
  "Halfway back (P3)",
  "Top of backswing (P4)",
  "Downswing / transition (P5-P6)",
  "Impact position (P7)",
  "Follow-through / finish",
];

// ── POST /api/analyze ─────────────────────────────────────────
app.post("/api/analyze", upload.single("swing"), async (req, res) => {
  const uploadedPath = req.file?.path;
  let frameDir = null;

  try {
    if (!req.file) return res.status(400).json({ error: "No file uploaded" });

    const { swingType, level, angle, feels, notes } = req.body;
    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (!apiKey) return res.status(500).json({ error: "ANTHROPIC_API_KEY not set in environment" });

    const isVideo = req.file.mimetype.startsWith("video/") ||
      /\.(mp4|mov|m4v|avi|mkv|webm|3gp)$/i.test(req.file.originalname);

    let imageContents = []; // Array of { base64, label }

    if (isVideo) {
      // Extract 6 frames across the full swing
      const { files, frameDir: fd, timestamps, duration } = await extractFrames(uploadedPath, 6);
      frameDir = fd;

      imageContents = files.map((f, i) => ({
        base64: fileToBase64(f),
        label:  POSITION_LABELS[i] || `Frame ${i + 1}`,
        timestamp: timestamps[i],
      }));

      console.log(`Extracted ${imageContents.length} frames from ${duration.toFixed(1)}s video`);
    } else {
      // Single image — treat as one frame
      imageContents = [{
        base64: fileToBase64(uploadedPath),
        label:  "Submitted swing frame",
      }];
    }

    // ── Build Claude API message content ─────────────────────
    // Interleave images with position labels so Claude sees each frame in context
    const messageContent = [];

    messageContent.push({
      type: "text",
      text: `You are CaddyIQ's elite AI swing coach, combining the expertise of Butch Harmon, Sean Foley, Claude Harmon III, Pete Cowen, and Dave Phillips with biomechanical analysis of tour-level swings.

You are analyzing a ${swingType || "full"} swing submitted by a ${level || "mid-handicap"} golfer.
Camera angle: ${angle || "unknown"}
Feel issues flagged by the player: ${feels || "none specified"}
Player notes: ${notes || "none"}

${isVideo
  ? `You have been provided ${imageContents.length} frames extracted evenly across the full swing video. Each frame is labeled with its position in the swing sequence. Analyze ALL frames together to build a complete picture of the swing, noting what is happening at each key position.`
  : `You have been provided a single swing image. Analyze what you can see.`
}

Your analysis must:
1. Reference specific swing positions by name (P1–P7, address, impact, finish)
2. Naturally reference real PGA Tour players — Rory McIlroy's lower body drive, Cameron Champ's shallowing move, Jon Rahm's compact power, Dustin Johnson's bowed wrist, Tiger's hip clearance, Scottie Scheffler's head stability, Xander Schauffele's transition
3. Cite real coaches with their specific teaching principles — Butch Harmon, Sean Foley, Claude Harmon III, Pete Cowen, Monte Scheinblum
4. Provide FEELING cues — tactile physical sensations the golfer can replicate on the range
5. Provide named practice drills with reps/sets
6. Adjust depth for: ${level || "mid-handicap"}${(level || "").includes("Beginner") ? ". Plain English only, zero tour jargon, explain every concept simply" : ""}
7. Prioritize fixes by impact — the one change that unlocks the most improvement comes first

Return ONLY a valid JSON object. Start with { and end with }. No markdown, no preamble.

Required JSON shape:
{
  "overallScore": <integer 1-100>,
  "swingType": "<string>",
  "summary": "<2 sentence overall read of the swing>",
  "videoFramesAnalyzed": <integer>,
  "positionBreakdown": [
    { "position": "<e.g. P1 Address>", "observation": "<what you see in this frame>", "rating": <1-10> }
  ],
  "scores": { "setup": <int>, "backswing": <int>, "downswing": <int>, "impact": <int> },
  "fixes": [
    {
      "priority": <1|2|3>,
      "title": "<fault name>",
      "position": "<position where fault occurs>",
      "description": "<clear explanation of fault and ball flight consequence>",
      "proRef": { "player": "<Tour player>", "initials": "<2 chars>", "comparison": "<how they do it right>" },
      "coachRef": "<coach name and their specific principle>",
      "feelingCue": "<tactile sensation to feel and replicate>",
      "practiceDrill": { "name": "<drill name>", "description": "<how to do it>", "reps": "<reps/sets>" },
      "beginnerTip": "<plain English explanation with zero jargon>"
    }
  ],
  "youtubeSearches": [
    { "query": "<search term>", "tag": "<fault category>", "channel": "<recommended channel>" }
  ]
}`
    });

    // Add each frame with its label
    imageContents.forEach(({ base64, label }, i) => {
      messageContent.push({ type: "text", text: `--- Frame ${i + 1}: ${label} ---` });
      messageContent.push({
        type: "image",
        source: { type: "base64", media_type: "image/jpeg", data: base64 },
      });
    });

    messageContent.push({
      type: "text",
      text: "Now analyze all the frames above together and return your complete JSON analysis.",
    });

    // ── Call Claude API ───────────────────────────────────────
    const claudeRes = await axios.post(
      "https://api.anthropic.com/v1/messages",
      {
        model:      "claude-sonnet-4-6",
        max_tokens: 4000,
        messages:   [{ role: "user", content: messageContent }],
      },
      {
        headers: {
          "x-api-key":         apiKey,
          "anthropic-version": "2023-06-01",
          "content-type":      "application/json",
        },
        timeout: 120000,
      }
    );

    const raw     = claudeRes.data.content?.find(b => b.type === "text")?.text || "";
    const cleaned = raw.replace(/```json\n?|```\n?/g, "").trim();
    let parsed;
    try {
      parsed = JSON.parse(cleaned);
    } catch {
      const match = cleaned.match(/\{[\s\S]*\}/);
      if (match) parsed = JSON.parse(match[0]);
      else throw new Error("Could not parse AI response as JSON");
    }

    parsed.videoFramesAnalyzed = imageContents.length;
    parsed.isVideoAnalysis = isVideo;

    res.json({ success: true, analysis: parsed });

  } catch (err) {
    console.error("Analysis error:", err.message);
    res.status(500).json({
      error: err.response?.data?.error?.message || err.message || "Analysis failed",
    });
  } finally {
    if (uploadedPath) cleanup(uploadedPath);
    if (frameDir)     cleanup(frameDir);
  }
});

// ── Health check ──────────────────────────────────────────────
app.get("/api/health", (req, res) => res.json({ status: "ok", ffmpeg: ffmpegPath }));

// ── Catch-all → React app ─────────────────────────────────────
app.get("*", (req, res) => {
  const index = path.join(clientBuild, "index.html");
  if (fs.existsSync(index)) res.sendFile(index);
  else res.send("CaddyIQ API running. Start the React client separately in development.");
});

app.listen(PORT, () => console.log(`CaddyIQ server running on port ${PORT}`));
