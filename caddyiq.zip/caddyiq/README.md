# CaddyIQ — AI Golf Swing Analyzer

Full-stack Node.js + React app with FFmpeg video processing and Claude AI analysis.

---

## Setup on Replit (15 minutes)

### Step 1 — Create the Repl
1. Go to replit.com → Create Repl → choose **Node.js**
2. Name it `caddyiq`

### Step 2 — Upload all files
Upload this entire folder structure into your Repl:
```
caddyiq/
├── package.json
├── .env.example
├── server/
│   └── index.js
└── client/
    ├── package.json
    ├── vite.config.js
    ├── index.html
    └── src/
        ├── main.jsx
        └── App.jsx
```

### Step 3 — Add your Anthropic API key
1. In Replit, click the **padlock icon** (Secrets) in the left sidebar
2. Add a new secret:
   - Key: `ANTHROPIC_API_KEY`
   - Value: your API key from console.anthropic.com

### Step 4 — Install dependencies
In the Replit Shell tab, run:
```bash
npm run install-all
```

### Step 5 — Build the React frontend
```bash
npm run build
```

### Step 6 — Start the server
```bash
npm start
```

Replit will give you a public URL. Open it — CaddyIQ is live.

---

## How it works

1. User uploads iPhone video (MOV, MP4, HEVC — any format)
2. Server receives video via Express/Multer
3. FFmpeg extracts 6 frames evenly across the full swing
4. All 6 frames sent to Claude Vision with position labels (P1–P7)
5. Claude analyzes each position and returns structured coaching JSON
6. React frontend displays position-by-position breakdown, fixes, feeling cues, and YouTube drill links

---

## Development (local machine)

```bash
npm run install-all
# Add ANTHROPIC_API_KEY to .env
npm run dev
# Server: localhost:3001
# Client: localhost:5173
```

---

## Tech stack
- **Backend**: Node.js, Express, Multer, fluent-ffmpeg
- **AI**: Claude claude-sonnet-4-6 via Anthropic API
- **Frontend**: React 18, Vite
- **Video**: FFmpeg (via @ffmpeg-installer/ffmpeg)
