import { useState, useRef, useCallback } from "react";

const G = {
  900:"#052e16",800:"#0a1f14",700:"#14532d",
  600:"#166534",500:"#16a34a",400:"#22c55e",
  300:"#4ade80",100:"#dcfce7",50:"#f0fdf4",
};
const S = {
  900:"#0f172a",700:"#334155",500:"#64748b",
  400:"#94a3b8",200:"#e2e8f0",100:"#f1f5f9",50:"#f8fafc",
};

const FEEL_TAGS = [
  "Thin / fat contact","Hook / slice","Stuck at top","Too steep",
  "Early release","Poor tempo","Weak at impact","Grip tension",
  "Over-the-top","Short backswing",
];
const SWING_TYPES = [
  { id:"Full swing",  icon:"🏌️", sub:"Driver, irons, fairway" },
  { id:"Short game",  icon:"⛳",  sub:"Chipping, pitching" },
  { id:"Putting",     icon:"🎯",  sub:"Green reading, stroke" },
];
const LEVELS = [
  "Beginner",
  "Mid-handicap (10–20 hcp)",
  "Low-handicap (under 10 hcp)",
  "Competitive / scratch",
];
const ANGLES = ["Face-on","Down-the-line","Both","Not sure"];
const LOADING_STEPS = [
  "Uploading your swing video…",
  "Extracting frames with FFmpeg…",
  "Analyzing swing positions P1–P7…",
  "Cross-referencing tour biomechanics…",
  "Building feeling drills & fixes…",
];

// ── Step Nav ──────────────────────────────────────────────────
function StepNav({ current }) {
  const steps = ["Setup","Submit","Analysis","Progress"];
  return (
    <div style={{ display:"flex", alignItems:"center", marginBottom:28 }}>
      {steps.map((s, i) => {
        const n=i+1, done=n<current, active=n===current;
        return (
          <div key={s} style={{ display:"flex", alignItems:"center", flex:i<steps.length-1?1:0 }}>
            <div style={{ display:"flex", alignItems:"center", gap:8 }}>
              <div style={{
                width:28,height:28,borderRadius:"50%",display:"flex",alignItems:"center",
                justifyContent:"center",fontSize:12,fontWeight:600,flexShrink:0,
                background: active?G[500]:done?G[700]:"transparent",
                border: active||done?`1.5px solid ${G[500]}`:"1.5px solid rgba(255,255,255,.2)",
                color: active?"#fff":done?G[300]:"rgba(255,255,255,.35)",
              }}>
                {done ? "✓" : n}
              </div>
              <span style={{ fontSize:12,fontWeight:500,whiteSpace:"nowrap",
                color:active?"#fff":"rgba(255,255,255,.35)" }}>{s}</span>
            </div>
            {i<steps.length-1 && (
              <div style={{ flex:1,height:1,background:"rgba(255,255,255,.12)",margin:"0 10px",minWidth:8 }} />
            )}
          </div>
        );
      })}
    </div>
  );
}

// ── Score pill ────────────────────────────────────────────────
function ScorePill({ v }) {
  const c = v>=75?G[300]:v>=55?"#fbbf24":"#f87171";
  return <span style={{ color:c, fontSize:20, fontWeight:700 }}>{Math.round(v)}</span>;
}

// ── Position Breakdown ────────────────────────────────────────
function PositionBreakdown({ positions }) {
  if (!positions?.length) return null;
  return (
    <div style={{ marginBottom:20 }}>
      <div style={{ fontSize:10,fontWeight:600,letterSpacing:".1em",textTransform:"uppercase",color:G[300],marginBottom:12 }}>
        Frame-by-frame breakdown
      </div>
      <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
        {positions.map((p, i) => (
          <div key={i} style={{ background:"rgba(255,255,255,.05)",borderRadius:10,padding:"12px 14px",display:"flex",alignItems:"flex-start",gap:12 }}>
            <div style={{ width:32,height:32,background:G[900],borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",fontSize:13,fontWeight:700,color:p.rating>=7?G[300]:p.rating>=5?"#fbbf24":"#f87171",flexShrink:0,border:`1.5px solid ${p.rating>=7?G[500]:p.rating>=5?"rgba(251,191,36,.5)":"rgba(248,113,113,.5)"}` }}>
              {p.rating}
            </div>
            <div style={{ flex:1 }}>
              <div style={{ fontSize:12,fontWeight:700,color:"#fff",marginBottom:3 }}>{p.position}</div>
              <div style={{ fontSize:12,color:"rgba(255,255,255,.6)",lineHeight:1.5 }}>{p.observation}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Fix Card ──────────────────────────────────────────────────
function FixCard({ fix, idx, beginner }) {
  const tiers = [
    { bg:"#fef2f2", c:"#dc2626", label:"Priority fix" },
    { bg:"#fff7ed", c:"#d97706", label:"Secondary fix" },
    { bg:"#f0fdf4", c:"#16a34a", label:"Bonus tip" },
  ];
  const t = tiers[idx] || tiers[2];
  return (
    <div style={{ background:"#fff",borderRadius:18,padding:22,marginBottom:14,color:S[900] }}>
      <div style={{ display:"flex",alignItems:"center",gap:8,marginBottom:10 }}>
        <span style={{ background:t.bg,color:t.c,fontSize:10,fontWeight:700,
          textTransform:"uppercase",letterSpacing:".06em",padding:"3px 10px",borderRadius:100 }}>
          {t.label}
        </span>
        <span style={{ fontSize:11,color:S[400] }}>{fix.position}</span>
      </div>
      <div style={{ fontSize:16,fontWeight:700,marginBottom:4 }}>{fix.title}</div>
      <div style={{ fontSize:13,color:S[700],lineHeight:1.65,marginBottom:12 }}>{fix.description}</div>

      {fix.proRef?.player && (
        <div style={{ display:"flex",alignItems:"flex-start",gap:10,background:G[50],
          borderRadius:8,padding:"10px 12px",marginBottom:10,borderLeft:`3px solid ${G[500]}` }}>
          <div style={{ width:30,height:30,background:G[700],borderRadius:"50%",display:"flex",
            alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:700,color:G[300],flexShrink:0 }}>
            {(fix.proRef.initials||fix.proRef.player?.slice(0,2)||"??").toUpperCase()}
          </div>
          <div style={{ fontSize:12,color:G[700],lineHeight:1.5 }}>
            <strong style={{ color:G[600] }}>{fix.proRef.player}</strong> — {fix.proRef.comparison}
          </div>
        </div>
      )}

      {fix.coachRef && (
        <div style={{ fontSize:12,color:S[500],marginBottom:10,padding:"8px 12px",
          background:S[50],borderRadius:8,borderLeft:`3px solid ${S[200]}` }}>
          <strong style={{ color:S[700] }}>Coach insight: </strong>{fix.coachRef}
        </div>
      )}

      <div style={{ background:G[900],borderRadius:8,padding:"12px 14px",border:"1px solid rgba(74,222,128,.2)" }}>
        <div style={{ fontSize:10,fontWeight:700,color:G[300],textTransform:"uppercase",
          letterSpacing:".08em",marginBottom:5 }}>Feeling cue</div>
        <div style={{ fontSize:13,color:"rgba(255,255,255,.88)",lineHeight:1.6,fontStyle:"italic" }}>
          "{fix.feelingCue}"
        </div>
        {fix.practiceDrill && (
          <div style={{ marginTop:10,paddingTop:10,borderTop:"1px solid rgba(74,222,128,.15)" }}>
            <div style={{ fontSize:11,fontWeight:700,color:G[300],marginBottom:3 }}>
              {fix.practiceDrill.name} — {fix.practiceDrill.reps}
            </div>
            <div style={{ fontSize:12,color:"rgba(255,255,255,.6)",lineHeight:1.5 }}>
              {fix.practiceDrill.description}
            </div>
          </div>
        )}
      </div>

      {beginner && fix.beginnerTip && (
        <div style={{ background:"#fffbeb",border:"1px solid #fcd34d",borderRadius:8,
          padding:"10px 12px",marginTop:10 }}>
          <div style={{ fontSize:10,fontWeight:700,color:"#d97706",textTransform:"uppercase",
            letterSpacing:".06em",marginBottom:3 }}>Simple explanation</div>
          <div style={{ fontSize:12,color:"#92400e",lineHeight:1.5 }}>{fix.beginnerTip}</div>
        </div>
      )}
    </div>
  );
}

// ── Upload Zone ───────────────────────────────────────────────
function UploadZone({ onFile, preview, previewType, onRemove, uploading }) {
  const ref = useRef();
  const [dragging, setDragging] = useState(false);

  const pick = e => { const f=e.target.files?.[0]; if(f) onFile(f); e.target.value=""; };
  const drop  = e => {
    e.preventDefault(); setDragging(false);
    const f=e.dataTransfer.files?.[0]; if(f) onFile(f);
  };

  if (uploading) return (
    <div style={{ border:"2px dashed rgba(74,222,128,.3)",borderRadius:14,padding:"44px 20px",
      textAlign:"center",background:"rgba(74,222,128,.03)" }}>
      <div style={{ fontSize:14,color:G[300],fontWeight:600,marginBottom:6 }}>
        Preparing your swing…
      </div>
      <div style={{ fontSize:12,color:"rgba(255,255,255,.4)" }}>Video processing begins on upload</div>
    </div>
  );

  if (preview) return (
    <div style={{ position:"relative",borderRadius:12,overflow:"hidden" }}>
      {previewType === "video" ? (
        <video src={preview} controls style={{ width:"100%",maxHeight:360,borderRadius:12,background:"#000",display:"block" }} />
      ) : (
        <img src={preview} alt="Swing preview" style={{ width:"100%",maxHeight:360,objectFit:"contain",background:"#000",display:"block",borderRadius:12 }} />
      )}
      <button onClick={onRemove} style={{ position:"absolute",top:10,right:10,
        background:"rgba(0,0,0,.7)",border:"none",borderRadius:100,color:"#fff",
        padding:"5px 14px",fontSize:12,cursor:"pointer",fontFamily:"inherit" }}>
        Remove
      </button>
    </div>
  );

  return (
    <div onDragOver={e=>{e.preventDefault();setDragging(true);}}
      onDragLeave={()=>setDragging(false)} onDrop={drop}
      onClick={()=>ref.current?.click()}
      style={{ border:`2px dashed ${dragging?G[400]:"rgba(74,222,128,.35)"}`,borderRadius:14,
        padding:"40px 20px",textAlign:"center",cursor:"pointer",
        background:dragging?"rgba(74,222,128,.08)":"rgba(74,222,128,.03)",transition:"all .2s" }}>
      <input ref={ref} type="file" style={{ display:"none" }}
        accept="video/*,image/*,.mov,.mp4,.m4v,.avi,.mkv,.webm,.heic,.heif,.jpg,.jpeg,.png"
        onChange={pick} />
      <div style={{ width:60,height:60,background:"rgba(74,222,128,.12)",borderRadius:16,
        display:"flex",alignItems:"center",justifyContent:"center",margin:"0 auto 18px" }}>
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
          <rect x="2" y="4" width="20" height="16" rx="3" stroke="#4ade80" strokeWidth="1.8"/>
          <path d="M10 9l5 3-5 3V9z" fill="#4ade80"/>
          <circle cx="18" cy="5" r="3" fill="#22c55e"/>
        </svg>
      </div>
      <div style={{ fontSize:17,fontWeight:700,marginBottom:8 }}>Upload your swing video</div>
      <div style={{ fontSize:13,color:"rgba(255,255,255,.5)",lineHeight:1.8 }}>
        <span style={{ color:G[300],fontWeight:600 }}>iPhone videos upload directly — any format</span><br/>
        MOV, MP4, M4V, HEVC · Photos &amp; screenshots also accepted<br/>
        <span style={{ fontSize:11,color:"rgba(255,255,255,.35)" }}>Up to 500MB · FFmpeg handles all codecs server-side</span>
      </div>
      <div style={{ marginTop:18,display:"inline-block",background:G[500],color:"#fff",
        padding:"11px 28px",borderRadius:10,fontSize:14,fontWeight:700 }}>
        Choose file
      </div>
    </div>
  );
}

// ── Main App ──────────────────────────────────────────────────
export default function App() {
  const [step, setStep]           = useState(1);
  const [swingType, setSwingType] = useState("Full swing");
  const [level, setLevel]         = useState("Mid-handicap (10–20 hcp)");
  const [angle, setAngle]         = useState("Face-on");
  const [feels, setFeels]         = useState([]);
  const [file, setFile]           = useState(null);
  const [preview, setPreview]     = useState(null);
  const [previewType, setPreviewType] = useState("image");
  const [notes, setNotes]         = useState("");
  const [loading, setLoading]     = useState(false);
  const [loadStep, setLoadStep]   = useState(0);
  const [result, setResult]       = useState(null);
  const [error, setError]         = useState("");
  const [history, setHistory]     = useState(() => {
    try { return JSON.parse(localStorage.getItem("ciq_swings")||"[]"); } catch { return []; }
  });

  const toggleFeel = t => setFeels(f => f.includes(t)?f.filter(x=>x!==t):[...f,t]);

  const handleFile = useCallback(f => {
    if (!f) return;
    setError("");
    setFile(f);
    const isVid = f.type.startsWith("video/") || /\.(mp4|mov|m4v|avi|mkv|webm|3gp)$/i.test(f.name);
    setPreviewType(isVid ? "video" : "image");
    setPreview(URL.createObjectURL(f));
  }, []);

  const removeFile = () => { setFile(null); setPreview(null); setError(""); };

  const runAnalysis = async () => {
    if (!file) { setError("Please upload a swing video or photo first."); return; }
    setError(""); setLoading(true); setStep(3); setLoadStep(0);

    const iv = setInterval(() => setLoadStep(s => Math.min(s+1, LOADING_STEPS.length-1)), 2000);

    try {
      const form = new FormData();
      form.append("swing", file);
      form.append("swingType", swingType);
      form.append("level", level);
      form.append("angle", angle);
      form.append("feels", feels.join(", ") || "none");
      form.append("notes", notes || "none");

      const res = await fetch("/api/analyze", { method:"POST", body:form });
      const data = await res.json();

      clearInterval(iv); setLoadStep(LOADING_STEPS.length-1);

      if (!res.ok || !data.success) throw new Error(data.error || "Analysis failed");

      const entry = {
        date: new Date().toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"}),
        swingType, level,
        score: data.analysis.overallScore,
        frames: data.analysis.videoFramesAnalyzed,
        topFix: data.analysis.fixes?.[0]?.title || "",
        id: Date.now(),
      };
      const newH = [entry, ...history].slice(0, 20);
      setHistory(newH);
      try { localStorage.setItem("ciq_swings", JSON.stringify(newH)); } catch {}

      setResult(data.analysis);
      setLoading(false);

    } catch(e) {
      clearInterval(iv);
      setLoading(false); setStep(2);
      setError(e.message || "Analysis failed — please try again.");
    }
  };

  const reset = () => {
    setStep(1); setFile(null); setPreview(null); setNotes("");
    setResult(null); setError(""); setFeels([]);
  };

  const css = {
    app:  { background:G[800],minHeight:"100vh",fontFamily:"system-ui,-apple-system,sans-serif",color:"#fff" },
    hdr:  { display:"flex",alignItems:"center",justifyContent:"space-between",
            padding:"18px 28px 14px",borderBottom:"1px solid rgba(255,255,255,.08)" },
    logo: { fontSize:22,fontWeight:800,letterSpacing:"-.4px" },
    badge:{ background:"rgba(74,222,128,.15)",border:"1px solid rgba(74,222,128,.3)",
            color:G[300],fontSize:11,fontWeight:600,padding:"4px 12px",borderRadius:100,letterSpacing:".04em" },
    wrap: { maxWidth:860,margin:"0 auto",padding:"28px 20px 80px" },
    card: { background:"rgba(255,255,255,.06)",border:"1px solid rgba(255,255,255,.1)",
            borderRadius:18,padding:26,marginBottom:16 },
    lbl:  { fontSize:10,fontWeight:600,letterSpacing:".1em",textTransform:"uppercase",
            color:G[300],marginBottom:8,display:"block" },
    h2:   { fontSize:26,fontWeight:800,marginBottom:6,lineHeight:1.2 },
    sub:  { fontSize:13,color:"rgba(255,255,255,.5)",lineHeight:1.6 },
    btnG: { width:"100%",padding:"14px 0",background:G[500],border:"none",borderRadius:12,
            color:"#fff",fontSize:15,fontWeight:700,cursor:"pointer",marginTop:10,fontFamily:"inherit" },
    btnS: { padding:"10px 18px",background:"rgba(255,255,255,.08)",
            border:"1px solid rgba(255,255,255,.15)",borderRadius:10,color:"#fff",
            fontSize:13,fontWeight:600,cursor:"pointer",fontFamily:"inherit" },
    tag:  (active) => ({
      padding:"6px 12px",borderRadius:100,cursor:"pointer",fontFamily:"inherit",fontSize:11,
      border: active?"1.5px solid #fbbf24":"1.5px solid rgba(255,255,255,.12)",
      background: active?"rgba(251,191,36,.12)":"transparent",
      color: active?"#fbbf24":"rgba(255,255,255,.5)",
    }),
    pill: (active) => ({
      padding:"7px 14px",borderRadius:100,cursor:"pointer",fontFamily:"inherit",fontSize:12,fontWeight:600,
      border: active?`1.5px solid ${G[500]}`:"1.5px solid rgba(255,255,255,.15)",
      background: active?G[500]:"transparent",
      color: active?"#fff":"rgba(255,255,255,.6)",
    }),
    chipAngle: (active) => ({
      padding:"7px 14px",borderRadius:100,cursor:"pointer",fontFamily:"inherit",fontSize:11,fontWeight:600,
      border: active?`1.5px solid ${G[400]}`:"1.5px solid rgba(255,255,255,.15)",
      background: active?"rgba(74,222,128,.15)":"transparent",
      color: active?G[300]:"rgba(255,255,255,.5)",
    }),
  };

  return (
    <div style={css.app}>
      <div style={css.hdr}>
        <div style={css.logo}>Caddy<span style={{ color:G[300] }}>IQ</span></div>
        <div style={css.badge}>AI Swing Analyzer</div>
      </div>

      <div style={css.wrap}>
        <StepNav current={step} />

        {/* ── Step 1: Setup ── */}
        {step===1 && (
          <div style={css.card}>
            <span style={css.lbl}>Step 1 of 4</span>
            <div style={css.h2}>What are we analyzing?</div>
            <div style={{ ...css.sub,marginBottom:26 }}>
              Select shot type and your level. The AI tailors its coaching depth accordingly.
            </div>

            <div style={{ fontSize:12,fontWeight:600,color:"rgba(255,255,255,.6)",marginBottom:10 }}>Shot type</div>
            <div style={{ display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:10,marginBottom:24 }}>
              {SWING_TYPES.map(s => (
                <div key={s.id} onClick={()=>setSwingType(s.id)} style={{
                  padding:"16px 10px",borderRadius:14,cursor:"pointer",textAlign:"center",
                  border: swingType===s.id?`1.5px solid ${G[400]}`:"1.5px solid rgba(255,255,255,.1)",
                  background: swingType===s.id?"rgba(74,222,128,.12)":"rgba(255,255,255,.04)",
                }}>
                  <div style={{ fontSize:24,marginBottom:6 }}>{s.icon}</div>
                  <div style={{ fontSize:12,fontWeight:700 }}>{s.id}</div>
                  <div style={{ fontSize:10,color:"rgba(255,255,255,.4)",marginTop:2 }}>{s.sub}</div>
                </div>
              ))}
            </div>

            <div style={{ fontSize:12,fontWeight:600,color:"rgba(255,255,255,.6)",marginBottom:8 }}>Your level</div>
            <div style={{ display:"flex",flexWrap:"wrap",gap:8,marginBottom:6 }}>
              {LEVELS.map(l => (
                <button key={l} onClick={()=>setLevel(l)} style={css.pill(level===l)}>
                  {l.split(" ")[0]}
                </button>
              ))}
            </div>
            {level.includes("Beginner") && (
              <div style={{ background:"rgba(251,191,36,.08)",border:"1px solid rgba(251,191,36,.25)",
                borderRadius:8,padding:"10px 12px",marginBottom:6 }}>
                <div style={{ fontSize:10,fontWeight:700,color:"#fbbf24",textTransform:"uppercase",letterSpacing:".06em",marginBottom:2 }}>
                  Beginner mode on
                </div>
                <div style={{ fontSize:12,color:"rgba(255,255,255,.7)",lineHeight:1.5 }}>
                  Plain English only — no tour jargon, every concept explained simply.
                </div>
              </div>
            )}

            <div style={{ fontSize:12,fontWeight:600,color:"rgba(255,255,255,.6)",marginBottom:8,marginTop:18 }}>Camera angle</div>
            <div style={{ display:"flex",gap:8,flexWrap:"wrap",marginBottom:20 }}>
              {ANGLES.map(a => (
                <button key={a} onClick={()=>setAngle(a)} style={css.chipAngle(angle===a)}>{a}</button>
              ))}
            </div>

            <div style={{ fontSize:12,fontWeight:600,color:"rgba(255,255,255,.6)",marginBottom:8 }}>
              What felt off? <span style={{ color:"rgba(255,255,255,.3)",fontWeight:400 }}>(optional — helps the AI focus)</span>
            </div>
            <div style={{ display:"flex",flexWrap:"wrap",gap:8,marginBottom:26 }}>
              {FEEL_TAGS.map(t => (
                <button key={t} onClick={()=>toggleFeel(t)} style={css.tag(feels.includes(t))}>{t}</button>
              ))}
            </div>

            <button style={css.btnG} onClick={()=>setStep(2)}>
              Next — upload your swing →
            </button>
          </div>
        )}

        {/* ── Step 2: Upload ── */}
        {step===2 && (
          <div style={css.card}>
            <span style={css.lbl}>Step 2 of 4</span>
            <div style={css.h2}>Upload your swing</div>
            <div style={{ ...css.sub,marginBottom:20 }}>
              Upload your iPhone video directly — MOV, MP4, HEVC all supported. FFmpeg processes the video
              server-side and extracts 6 frames across your full swing for position-by-position analysis.
            </div>

            <UploadZone
              onFile={handleFile} preview={preview} previewType={previewType}
              onRemove={removeFile} uploading={false}
            />

            {file && (
              <div style={{ background:"rgba(74,222,128,.08)",border:"1px solid rgba(74,222,128,.2)",
                borderRadius:10,padding:"10px 14px",marginTop:12,fontSize:12,color:G[300] }}>
                <strong>{file.name}</strong> — {(file.size/1024/1024).toFixed(1)} MB ready to analyze
              </div>
            )}

            <div style={{ marginTop:20 }}>
              <div style={{ fontSize:12,fontWeight:600,color:"rgba(255,255,255,.6)",marginBottom:8 }}>
                Add context <span style={{ color:"rgba(255,255,255,.3)",fontWeight:400 }}>(optional)</span>
              </div>
              <textarea value={notes} onChange={e=>setNotes(e.target.value)} rows={3}
                placeholder="e.g. '7-iron, over the top, tends to slice. Feels stuck at the top of my backswing and like I'm losing lag early.'"
                style={{ width:"100%",background:"rgba(255,255,255,.06)",border:"1px solid rgba(255,255,255,.12)",
                  borderRadius:8,padding:"12px 14px",color:"#fff",fontSize:13,fontFamily:"inherit",
                  resize:"none",outline:"none",lineHeight:1.5,boxSizing:"border-box" }} />
            </div>

            {error && (
              <div style={{ background:"rgba(248,113,113,.1)",border:"1px solid rgba(248,113,113,.3)",
                borderRadius:8,padding:"12px 14px",color:"#f87171",fontSize:13,marginTop:12,lineHeight:1.5 }}>
                {error}
              </div>
            )}

            <div style={{ display:"flex",gap:10,marginTop:16 }}>
              <button style={{ ...css.btnS,flex:"0 0 84px" }} onClick={()=>{ setStep(1); setError(""); }}>
                ← Back
              </button>
              <button onClick={runAnalysis} disabled={!file} style={{
                flex:1,padding:"13px 0",border:"none",borderRadius:12,color:"#fff",
                fontSize:15,fontWeight:700,fontFamily:"inherit",
                background:file?G[500]:"rgba(22,163,74,.35)",
                cursor:file?"pointer":"not-allowed",
              }}>
                {file ? "Analyze my swing →" : "Upload a swing first"}
              </button>
            </div>
          </div>
        )}

        {/* ── Loading ── */}
        {loading && (
          <div style={{ textAlign:"center",padding:"56px 20px" }}>
            <div style={{ width:60,height:60,border:`3px solid rgba(74,222,128,.2)`,
              borderTopColor:G[400],borderRadius:"50%",animation:"spin 1s linear infinite",margin:"0 auto 24px" }} />
            <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
            <div style={{ fontSize:24,fontWeight:800,marginBottom:6 }}>Analyzing your swing</div>
            <div style={{ fontSize:13,color:"rgba(255,255,255,.5)",marginBottom:32 }}>
              Processing all positions across your full swing video…
            </div>
            <div style={{ display:"flex",flexDirection:"column",gap:8,maxWidth:340,margin:"0 auto" }}>
              {LOADING_STEPS.map((s,i) => (
                <div key={s} style={{ display:"flex",alignItems:"center",gap:10,
                  padding:"11px 14px",background:"rgba(255,255,255,.05)",borderRadius:8,
                  fontSize:12,textAlign:"left",
                  color:i<loadStep?G[300]:i===loadStep?"#fff":"rgba(255,255,255,.3)" }}>
                  <div style={{ width:8,height:8,borderRadius:"50%",flexShrink:0,
                    background:i<loadStep?G[400]:i===loadStep?"#fbbf24":"rgba(255,255,255,.15)" }} />
                  {s}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── Step 3: Results ── */}
        {!loading && result && step===3 && (
          <div>
            <span style={css.lbl}>Your analysis</span>
            <div style={{ ...css.h2,marginBottom:4 }}>Swing analysis complete</div>
            <div style={{ ...css.sub,marginBottom:6 }}>{result.summary}</div>

            {result.isVideoAnalysis && (
              <div style={{ display:"inline-flex",alignItems:"center",gap:6,
                background:"rgba(74,222,128,.1)",border:"1px solid rgba(74,222,128,.25)",
                borderRadius:100,padding:"4px 12px",marginBottom:20,fontSize:11,color:G[300],fontWeight:600 }}>
                <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                  <rect x="1" y="2" width="10" height="8" rx="1.5" stroke="#4ade80" strokeWidth="1.2"/>
                  <path d="M5 4.5l3 1.5-3 1.5V4.5z" fill="#4ade80"/>
                </svg>
                {result.videoFramesAnalyzed} frames analyzed across full swing
              </div>
            )}

            {/* Score header */}
            <div style={{ display:"flex",gap:14,marginBottom:22,flexWrap:"wrap" }}>
              <div style={{ flex:1,minWidth:140,background:G[900],border:"1px solid rgba(74,222,128,.2)",
                borderRadius:18,padding:22,textAlign:"center" }}>
                <div style={{ fontSize:56,fontWeight:800,color:G[300],lineHeight:1 }}>
                  {Math.round(result.overallScore)}
                </div>
                <div style={{ fontSize:11,color:"rgba(255,255,255,.45)",textTransform:"uppercase",
                  letterSpacing:".08em",marginTop:4 }}>Overall</div>
              </div>
              <div style={{ flex:2,display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,minWidth:200 }}>
                {Object.entries(result.scores||{}).map(([k,v]) => (
                  <div key={k} style={{ background:"rgba(255,255,255,.05)",borderRadius:10,padding:"12px 14px" }}>
                    <div style={{ fontSize:10,color:"rgba(255,255,255,.4)",textTransform:"uppercase",
                      letterSpacing:".06em",marginBottom:4 }}>{k}</div>
                    <ScorePill v={v} />
                  </div>
                ))}
              </div>
            </div>

            {/* Position breakdown — only for video */}
            {result.isVideoAnalysis && <PositionBreakdown positions={result.positionBreakdown} />}

            {/* Fix cards */}
            {(result.fixes||[]).map((fix,i) => (
              <FixCard key={i} fix={fix} idx={i} beginner={level.includes("Beginner")} />
            ))}

            {/* YouTube */}
            {result.youtubeSearches?.length > 0 && (
              <div style={{ marginTop:22 }}>
                <span style={css.lbl}>Recommended drills to watch</span>
                <div style={{ display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(220px,1fr))",
                  gap:12,marginTop:12 }}>
                  {result.youtubeSearches.map((yt,i) => (
                    <a key={i}
                      href={`https://www.youtube.com/results?search_query=${encodeURIComponent(yt.query)}`}
                      target="_blank" rel="noreferrer"
                      style={{ background:"rgba(255,255,255,.06)",border:"1px solid rgba(255,255,255,.1)",
                        borderRadius:14,overflow:"hidden",textDecoration:"none",display:"block" }}>
                      <div style={{ height:76,background:G[900],display:"flex",alignItems:"center",justifyContent:"center" }}>
                        <div style={{ width:38,height:38,background:"rgba(255,255,255,.1)",borderRadius:"50%",
                          display:"flex",alignItems:"center",justifyContent:"center",
                          border:"2px solid rgba(255,255,255,.2)" }}>
                          <svg width="13" height="15" viewBox="0 0 12 14">
                            <polygon points="2,1 11,7 2,13" fill="white"/>
                          </svg>
                        </div>
                      </div>
                      <div style={{ padding:"10px 12px" }}>
                        <div style={{ display:"inline-block",background:"rgba(74,222,128,.15)",
                          color:G[300],borderRadius:100,padding:"2px 7px",fontSize:9,
                          fontWeight:700,marginBottom:5 }}>{yt.tag}</div>
                        <div style={{ fontSize:12,fontWeight:600,color:"#fff",lineHeight:1.4,marginBottom:3 }}>
                          {yt.query}
                        </div>
                        <div style={{ fontSize:10,color:"rgba(255,255,255,.4)" }}>{yt.channel}</div>
                      </div>
                    </a>
                  ))}
                </div>
              </div>
            )}

            <div style={{ display:"flex",gap:10,marginTop:26,flexWrap:"wrap" }}>
              <button style={css.btnS} onClick={reset}>Analyze another swing</button>
              <button style={{ ...css.btnS,background:G[500],border:"none" }} onClick={()=>setStep(4)}>
                View progress →
              </button>
            </div>
          </div>
        )}

        {/* ── Step 4: Progress ── */}
        {step===4 && (
          <div style={css.card}>
            <span style={css.lbl}>Progress timeline</span>
            <div style={{ ...css.h2,marginBottom:4 }}>Swing history</div>
            <div style={{ ...css.sub,marginBottom:22 }}>
              Every submission is saved so you can track which faults are improving over time.
            </div>
            {history.length===0 ? (
              <div style={{ textAlign:"center",padding:32,background:"rgba(255,255,255,.04)",
                borderRadius:12,border:"1px dashed rgba(255,255,255,.1)" }}>
                <p style={{ fontSize:13,color:"rgba(255,255,255,.4)" }}>No swings logged yet.</p>
              </div>
            ) : history.map((s,i) => {
              const c = s.score>=75?G[300]:s.score>=55?"#fbbf24":"#f87171";
              return (
                <div key={s.id} style={{ display:"flex",gap:14,alignItems:"flex-start",
                  padding:"16px 0",borderBottom:"1px solid rgba(255,255,255,.08)" }}>
                  <div style={{ width:46,height:46,borderRadius:"50%",background:"rgba(255,255,255,.06)",
                    display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0 }}>
                    <span style={{ fontSize:17,fontWeight:700,color:c }}>{Math.round(s.score)}</span>
                  </div>
                  <div style={{ flex:1 }}>
                    <div style={{ fontSize:13,fontWeight:600,marginBottom:2 }}>
                      {s.date} · {s.swingType}
                      {s.frames && <span style={{ fontSize:10,color:G[300],fontWeight:600,marginLeft:8,
                        background:"rgba(74,222,128,.1)",padding:"2px 7px",borderRadius:100 }}>
                        {s.frames} frames
                      </span>}
                    </div>
                    <div style={{ fontSize:11,color:"rgba(255,255,255,.45)",marginBottom:5 }}>{s.level}</div>
                    <div style={{ fontSize:12,color:"rgba(255,255,255,.6)" }}>
                      Top fix: <span style={{ color:G[300],fontWeight:600 }}>{s.topFix}</span>
                    </div>
                  </div>
                  {i===0 && (
                    <span style={{ fontSize:10,background:"rgba(74,222,128,.15)",color:G[300],
                      padding:"3px 8px",borderRadius:100,fontWeight:600 }}>Latest</span>
                  )}
                </div>
              );
            })}
            <button style={{ ...css.btnG,marginTop:22 }} onClick={reset}>Analyze new swing</button>
          </div>
        )}
      </div>
    </div>
  );
}
